'use client';

import { useMemo, useCallback } from 'react';
import { useFilterStore } from '@/stores/filter-store';
import { classifyAircraft, isEmergency, isOnGround, getDataSource } from '@/lib/classify';

/**
 * Hook to filter aircraft based on current filter state
 */
export function useFilteredAircraft(aircraft) {
  const { filters } = useFilterStore();

  const filteredAircraft = useMemo(() => {
    if (!aircraft || !Array.isArray(aircraft)) {
      return [];
    }

    return aircraft.filter((ac) => {
      // Type filter
      const type = classifyAircraft(ac);
      if (!filters.types[type] && type !== 'emergency') {
        return false;
      }

      // Altitude filter
      if (filters.altitude.enabled) {
        const altitude = ac.alt_baro || ac.alt_geom || 0;
        if (altitude === 'ground') {
          if (filters.altitude.min > 0) return false;
        } else if (altitude < filters.altitude.min || altitude > filters.altitude.max) {
          return false;
        }
      }

      // Speed filter
      if (filters.speed.enabled) {
        const speed = ac.gs || 0;
        if (speed < filters.speed.min || speed > filters.speed.max) {
          return false;
        }
      }

      // Status filter (airborne/ground)
      const onGround = isOnGround(ac);
      if (onGround && !filters.status.onGround) {
        return false;
      }
      if (!onGround && !filters.status.airborne) {
        return false;
      }

      // Data source filter
      const dataSource = getDataSource(ac);
      if (!filters.dataSource[dataSource]) {
        return false;
      }

      // Special filters
      if (filters.special.military && type !== 'military') {
        return false;
      }

      if (filters.special.emergency && !isEmergency(ac)) {
        // If emergency filter is specifically set, only show emergencies
        // But if all special filters are off, show everything
        if (filters.special.emergency && !filters.special.military && !filters.special.interesting) {
          // Emergency is the only filter, but don't filter by it
        }
      }

      // Search filter
      if (filters.search.query) {
        const query = filters.search.query.toLowerCase().trim();
        const field = filters.search.field;

        let matches = false;

        if (field === 'all' || field === 'callsign') {
          if (ac.flight && ac.flight.toLowerCase().includes(query)) {
            matches = true;
          }
        }

        if (field === 'all' || field === 'registration') {
          if (ac.r && ac.r.toLowerCase().includes(query)) {
            matches = true;
          }
        }

        if (field === 'all' || field === 'type') {
          if (ac.t && ac.t.toLowerCase().includes(query)) {
            matches = true;
          }
        }

        if (!matches) {
          return false;
        }
      }

      return true;
    });
  }, [aircraft, filters]);

  return filteredAircraft;
}

/**
 * Hook to get filter statistics
 */
export function useFilterStats(aircraft) {
  const filteredAircraft = useFilteredAircraft(aircraft);

  const stats = useMemo(() => {
    const byType = {
      commercial: 0,
      cargo: 0,
      military: 0,
      private: 0,
      helicopter: 0,
      government: 0,
      special: 0,
      unknown: 0,
    };

    let inEmergency = 0;
    let adsb = 0;
    let mlat = 0;

    filteredAircraft.forEach((ac) => {
      const type = classifyAircraft(ac);
      if (byType[type] !== undefined) {
        byType[type]++;
      }

      if (isEmergency(ac)) {
        inEmergency++;
      }

      const source = getDataSource(ac);
      if (source === 'adsb') adsb++;
      if (source === 'mlat') mlat++;
    });

    return {
      total: filteredAircraft.length,
      byType,
      inEmergency,
      dataSource: { adsb, mlat },
    };
  }, [filteredAircraft]);

  return stats;
}

/**
 * Hook to check if any filters are active
 */
export function useHasActiveFilters() {
  const { getActiveFilterCount } = useFilterStore();
  return getActiveFilterCount() > 0;
}
